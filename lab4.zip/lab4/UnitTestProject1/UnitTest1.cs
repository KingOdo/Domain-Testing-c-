﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using lab4;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        Citizen obj= new Citizen();
        User users= new User();
        GradeSystem grade = new GradeSystem();
        Shop discount= new Shop();

        [TestMethod]
        public void citizentest()
        {
            Assert.AreEqual("Eligible", obj.IsEligibleToVote(18));
            Assert.AreEqual("Not Eligible", obj.IsEligibleToVote(17));
            Assert.AreEqual("Eligible", obj.IsEligibleToVote(120));
            Assert.AreEqual("Not Eligible", obj.IsEligibleToVote(121));
        }
        [TestMethod]

        public void UserTest()
        {
            Assert.AreEqual("Invalid", users.IsValidPassword("12345"));
            Assert.AreEqual("Valid", users.IsValidPassword("123456"));
            Assert.AreEqual("Valid", users.IsValidPassword("123456789012"));
            Assert.AreEqual("Invalid", users.IsValidPassword("1234567890123"));
        }

        [TestMethod]
        public void GradeSystemTest()
        {
            Assert.AreEqual("Input a positive value", grade.IsValidGrade(-1));
            Assert.AreEqual("Valid", grade.IsValidGrade(0));
            Assert.AreEqual("Valid", grade.IsValidGrade(100));
            Assert.AreEqual("Invalid", grade.IsValidGrade(101));

        }

        [TestMethod]
        public void ShopTest()
        {
            Assert.AreEqual("Discount Not Applicable", discount.IsDiscountApplicable(49));
            Assert.AreEqual("Discount Applicable", discount.IsDiscountApplicable(99));
            Assert.AreEqual("Discount Applicable", discount.IsDiscountApplicable(50));
            Assert.AreEqual("Discount Applicable", discount.IsDiscountApplicable(500));
            Assert.AreEqual("Discount Not Applicable", discount.IsDiscountApplicable((decimal)500.01));
        }
    }
}
