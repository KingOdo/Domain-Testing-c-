﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    public class Citizen
    {
        public String IsEligibleToVote(int age)
        {
            if (age >= 18 && age <= 120)
            {
                return "Eligible";
            }
             else 
            {
                return "Not Eligible";
            }
        }
    }

    public class User
    {
        public string IsValidPassword(string password)
        {
            if (password.Length >= 6 && password.Length<= 12)
            {
                return "Valid";
            }
            else
            {
                return "Invalid";
            }
                
        }
    }

    public class GradeSystem
    {
        public string IsValidGrade(int grade)
        {
            if (grade < 0)
            {
                return "Input a positive value";
            }
            else if (grade >= 0 && grade <= 100)
            {
                return "Valid";
            }
            else // grade > 100
            {
                return "Invalid";
            }
        }

    }
    public class Shop
    {
        public string IsDiscountApplicable(decimal purchaseAmount)
        {
            if (purchaseAmount >= 50 && purchaseAmount <= 500)
            {
                return "Discount Applicable";
            }
            else
            {
                return "Discount Not Applicable";
            }
        }
    }

}
